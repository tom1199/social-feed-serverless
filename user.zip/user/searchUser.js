const randomBytes = require('crypto').randomBytes;

const AWS = require('aws-sdk');

const dynamodb = require("../dynamodb");

exports.handler = (event, context, callback) => {
    // if (!event.requestContext.authorizer) {
    //     errorResponse('Authorization not configured', context.awsRequestId, callback);
    //     return;
    // }
    
    var filterExpression = "";
    var searchFilter = "";
  
    if (event.queryStringParameters.searchFilter !== undefined &&
        event.queryStringParameters.searchFilter !== "") {
        searchFilter = event.queryStringParameters.searchFilter;
        //filterExpression = "contains(userId, :searchFilter) or contains(userName, :searchFilter) or contains(email, :searchFilter)";
        filterExpression = "contains(userName, :searchFilter)";
    }

    var params = "";
    
    if (searchFilter !== "") {
        params = {
            TableName: process.env.USER_TABLE,
            FilterExpression: filterExpression,
            ExpressionAttributeValues: {
                ":searchFilter": searchFilter
            }
    
        };
    } else {
        params = {
            TableName: process.env.USER_TABLE
        };
    }
  
    dynamodb.scan(params, (error, result) => {
        if (error) {
            console.error(error);
            
            const body = {
                error: "Internal Server Error" + error,
                message: "Couldn\'t get feeds." 
            };
            
            const response = {
                statusCode: error.statusCode || 501,
                headers: { 
                    'Content-Type': 'application/json', 
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify(body),
                isBase64Encoded: false
            }
            
            callback(null, response);
            return;
        }


        const body = {
            message: "success",
            users: result.Items
        };
        
        const response = {
            statusCode: 200,
            body: JSON.stringify(body),
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            isBase64Encoded: false
        };
        callback(null, response);
    });
};


